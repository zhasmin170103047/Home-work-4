<p>Username:{{$name}}</p>
<p>Password:{{$s_name}}</p>