<html>
    <head>
    <title>HW4</title>
    </head>
    <body>
        <form action="{{action(TaskController@show')}}" method="GET">
            Username:  <input type="text" name="username">
            <br><br>
            Password:  <input type="text" name="password">
            <br><br>
            <button type="submit">Submit</button>
        </form>
    </body>
</html>