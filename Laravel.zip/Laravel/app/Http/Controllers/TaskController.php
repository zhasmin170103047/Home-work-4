<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class TaskController extends Controller
{
    //

    public function index(){
 
        $task= Task::all();
 
        return view('task.index',compact('task'));
    }
 
    public function create(){
        return view('task.create');
    }
 
    public function storeTask(){
 
        $t = new Task();
 
        $t->name = request('name');
        $t->surname = request('surname');
 
        $t->save();
 
        return redirect('/task');
 
    }

     public function index(){
 
        $task = Device::all();
 
        return view('task.index',compact('task'));
    }

    
}
