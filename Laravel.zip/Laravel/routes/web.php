<?php

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/', function () {
    return view('welcome');
});
Route::post('/task','TaskController@send')->name('send.task');
 
Route::get('/task/create','TaskController@create');
 
Route::get('/task/show','TaskController@show');

Route::view('/',"userview");

Route::get('/usercontroller', 'contr@formSubmit');